import random
import time
import threading
import paho.mqtt.client as mqtt

MQTT_BROKER = "broker.hivemq.com"
MQTT_PORT = 8000  # WebSockets
MQTT_TOPIC = "atividade/temperatura"

def simulate_temperature():
    return round(random.uniform(20.0, 30.0), 2)

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("✅ Conectado ao broker MQTT!")
        client.subscribe(MQTT_TOPIC)
    else:
        print(f"❌ Falha na conexão, código: {rc}")

def on_message(client, userdata, msg):
    print(f"📥 Recebido: {msg.topic} -> {msg.payload.decode()}")

def publisher():
    client = mqtt.Client(client_id="", transport="websockets")  # sem callback_api_version
    client.connect(MQTT_BROKER, MQTT_PORT)
    client.loop_start()
    while True:
        temp = simulate_temperature()
        client.publish(MQTT_TOPIC, f"{temp}")
        print(f"📤 Publicado: {temp}°C")
        time.sleep(5)

def subscriber():
    client = mqtt.Client(client_id="", transport="websockets")  # sem callback_api_version
    client.on_connect = on_connect
    client.on_message = on_message
    client.connect(MQTT_BROKER, MQTT_PORT)
    client.loop_forever()

if __name__ == "__main__":
    threading.Thread(target=publisher, daemon=True).start()
    subscriber()
